const stringCalculate = require("./stringCalculate");

module.exports = {
    stringCalculate: stringCalculate
};